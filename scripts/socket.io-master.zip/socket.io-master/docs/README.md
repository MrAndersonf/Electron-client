
The documentation has been moved to the website [here](https://socket.io/docs/).
