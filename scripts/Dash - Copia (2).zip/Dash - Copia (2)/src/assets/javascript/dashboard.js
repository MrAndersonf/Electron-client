(async function() {
  feather.replace();
})();